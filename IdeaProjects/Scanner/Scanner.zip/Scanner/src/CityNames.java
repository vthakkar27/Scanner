import java.util.Scanner;

public class CityNames
{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char ch;
        System.out.println(" Enter any Alphabet: ");
        ch = scanner.next().charAt(0);

        if (ch == 'a') {
            System.out.println(" Aberdeen ");
        } else if (ch == 'b') {
            System.out.println(" Birmingham ");
        } else if (ch == 'c') {
            System.out.println(" Cardiff ");
        } else if (ch == 'd') {
            System.out.println(" Durham ");
        } else if (ch == 'e') {
            System.out.println(" Edinburgh ");
        } else if (ch == 'f')
        {
            System.out.println(" Falmouth ");
        }
    }
}